//'<!--Start of Build In Javascript Template-->'
var Template = (function() {
  var attributeTemplate = "" + 
        "<div class='well well-small'>" + 
          "<div>" + 
            "<h4 id='attrName-<%=id%>' class='attrName' contenteditable='<%=editable%>' ><%=name%></h4>" + 
            "<h4 style='text-align:right;'><%=rating%> </h4>" + 
          "</div>" + 
          "<div class='progress'>" + 
            "<div class='bar bar-success' style='width:<%=upVote%>%;'> <%=upVote%>+</div>" + 
            "<div class='bar bar-danger' style='width:<%=downVote%>%;'> <%=downVote%>-</div>" + 
          "</div>" + 
          "<a href='' class='btn voteBtn'><i class='icon-thumbs-down'></i></a>" + 
          "<a href='' class='btn voteBtn'><i class='icon-thumbs-up'></i></a>" + 
        "</div>",
      entityTemplate = "" +
        /*"<img id='img-<%=id%>' src='<%=imageURL%>'></img>" + 
        "<h5 class='tags'>" + 
          "<span>" + 
            "<%=tags%>" +
          "</span>" + 
        "</h5>" + */
        "<hr>" + 
        "<button class='toggleBtn btn' style='margin: -2.5em 0 1em 0;'>Expand <i id='toggleIcon-<%=id%>' class='icon-chevron-down'></i></button>" + 
        "<p class='description' style='display: none'><%=description%></p>",
      cardTemplate = "" +
        "<div class='card' style='max-width: 20em;'>" + 
          "<div id='' class='card-header'>" + 
            "<legend contenteditable='true' class='card-title'><%=cardTitle%></legend>" + 
          "</div>" + 
          "<div class='contentContainer outer'>" + 
            "<div class='inner'>" + 
              "<%=cardContent%>" + 
            "</div>" + 
          "</div>" + 
        "</div>",
      summaryCardTemplate = "" +
        "<div class='card' style='max-width: 20em;'>" + 
          "<div id='' class='card-header'>" + 
            "<legend contenteditable='true' class='card-title'><%=entity.name%></legend>" + 
          "</div>" + 
          "<div class='contentContainer outer'>" + 
            "<div class='inner'>" + 
              "<div class='summary'>" + 
                "<h2 class='pull-left' style='margin-top:0;'>Avg. <%=entity.avgScore%>% </h2>" + 
                "<ul class='pull-right'>" + 
                  "<li><%=entity.totalVote%> Votes</li>" + 
                  "<li><%=entity.totalAttribute%> Attributes</li>" + 
                "</ul>" + 
              "</div>" + 
              "<img id='img-<%=id%>' src='<%=imageURL%>'></img>" + 
              "<h5 class='tags'>" + 
                "<span>" + 
                  "<%=tags%>" +
                "</span>" + 
              "</h5>" + 
            "</div>" + 
            "<div>" + 
              "<ul id='myTab' class='nav nav-tabs inner'>" + 
                "<li class='active'><a href='#profile-<%=entity.id%>' data-toggle='tab'>Profile</a></li>" + 
                "<li><a href='#attributes-<%=entity.id%>' data-toggle='tab'>Attributes</a></li>" + 
              "</ul>" + 
              "<div id='myTabContent' class='tab-content'>" + 
                "<div class='tab-pane active' style='margin:0 1em 0.5em 1em;' id='profile-<%=entity.id%>'>" + 
                  "<div class='profileContent'></div>" +
                "</div>" + 
                "<div class='tab-pane' style='margin:0 1em 0.5em 1em;' id='attributes-<%=entity.id%>'>" + 
                  "<form class='form-search'>" + 
                    "<input type='text' class='input-medium search-query'>" + 
                    "<i class='icon-search' style='margin-left:-2em;'></i>" + 
                  "</form>" + 
                    "<div class='attrContent'></div>" +
                    //"<%=attributesContent%>" + 
                "</div>" + 
              "</div>" + 
            "</div>" + 
          "</div>" + 
        "</div>";
      
  return {
    attributeTemplate: attributeTemplate,
    entityTemplate: entityTemplate,
    cardTemplate: cardTemplate,
    summaryCardTemplate: summaryCardTemplate
  };
}) ();
