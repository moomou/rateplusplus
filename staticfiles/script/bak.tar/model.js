function guidGenerator() {
    var S4 = function() {
       return (((1+Math.random())*0x10000)|0).toString(16).substring(1);
    };
    return (S4()+S4()+"-"+S4()+"-"+S4()+"-"+S4()+"-"+S4()+S4()+S4());
}

var App = App || {};

App.API_VERSION = 'api/v0/';

App.EntityModel = Backbone.Model.extend({
	url: App.API_VERSION + 'entity/',
    defaults: {
    	id: undefined,
        name: '',
        imageURL: '',
        description: '',
        tags: [],
        attributes: undefined
    },
    validate: function(attribs) {
    	if (!attribs['id']) {
            console.log('Should have an id');
    	}
	},
    initialize: function() {
    },
    parse: function(response) {
        console.log('Parse in EntityModel');
    	console.log(response);
    }
});

App.EntityView = Backbone.View.extend({
    //tagName: "div",
    //className: "",
    template: _.template(Template.entityTemplate),
    events: {
        'click .tags': 'test'
    },
    //Builtin Function
    render: function() {
        this.$el.html(this.template(this.model.toJSON()));
        return this;
    },
    initialize: function() {
    },
    //Event Handler
    test: function() {
        console.log('entityTest');
    }
});

App.AttributeModel = Backbone.Model.extend({
    url: App.API_VERSION + 'attribute/',
    defaults: {
    	id: undefined,
        name: '',
        upVote: 0,
        downVote: 0,
        voteCount: 0,
        editable: false
    },
    //Builtin Function
    initialize: function() {
        var rating = this.get('upVote')/(this.get('voteCount') || 1);
        rating = this.get('voteCount') ? (rating*100).toFixed(2).toString() : 'N/A';

        this.set('rating', rating);
        this.set('upVote', rating);
        this.set('downVote', 100 - rating);

        //set events
        //this.on('change:title', function() { });
    },
    validate: function() {
    },
    parse: function(response) {
        console.log('Attribute Parse');
        console.log(response);
    }
});

App.AttributeView = Backbone.View.extend({
    template: _.template(Template.attributeTemplate),
    events: {
        'click .voteBtn': 'attrVote',
        'click .attrName': 'editName'
    },
    //Builtin Func
    render: function() {
        this.$el.html(this.template(this.model.toJSON()));
        return this;
    },
    initialize: function() {
        //attach up and down vote event
    },
    //Event Handler
    test: function() {
        console.log('hi');
    },
    attrVote: function(e) {
        e.preventDefault();
        console.log('attrVote called:');
    },
    editName: function(e) {
        console.log('editName called: '+ e.toString());
    }
});

App.SummaryCardModel = Backbone.Model.extend({
	defaults: {
		editable: false
	},
	initialize: function(spec) {
		/*
        this.on("change:highlight", "toggleHighlight", this);
		this.on("change:content", "updateContent", this);
		this.on("error", function(model, error) {
			console.log(error);
		});
        */
	},
	validate: function(attribs) {
	},
    parse: function(response) {
        console.log("SummaryCardModel Parse");

        this.set('entityView', this.getEntityView(new App.EntityModel(response))); 
        this.set('attributeViews', this.getAttributesView(response['attributes']));

        //response['entityContent'] = this.get('entityView').render().el.outerHTML;
        //response['attributesContent'] = this.get('attributeViews').render();

        response['entity'] = this.getEntityStats(response['attributes']); 
        response['entity']['name'] = response['name'];
        response['entity']['id'] = response['id'];
        response['entity']['totalAttribute'] = response['attributes'].length;

        return response;
    },
    //Custom Functions
    getEntityView: function(entityModel) {
        return new App.EntityView({model: entityModel}); //.render().el.outerHTML;
    },
    getAttributesView: function(attrModel) {
        return new App.AttributeCollectionView(attrModel);//.render();
    },
    getEntityStats: function(attrs) {
        var totalVote = 0;
        var avgScore = 0;

        _.each(attrs, function(attr) {
            totalVote += attr['voteCount'];
        });

        if (totalVote !== 0) {
            _.each(attrs, function(attr) {
                var attrScore = attr['upVote']/(attr['voteCount'] || 1);  //divide by totalCount unless 0
                avgScore += attrScore * (attr['voteCount']/(totalVote || 1));
            });
        }

        avgScore *= 100;

        return {
            'totalVote': totalVote,
            'avgScore': avgScore ? avgScore.toFixed(0).toString() : '-'
        };
    }
});

App.SummaryCardView = Backbone.View.extend({
	template: _.template(Template.summaryCardTemplate),
	events: {
        'click .card-title': 'test'
	},
    //Builtin Func
    initialize: function() {
		console.log("App.SummaryCardView initialize");
		//this.$el.addClass(card.model.get('cardType'));
		//this.model.on('change', this.render, this);
	},
	render: function(event) {
		console.log("App.SummaryCardView Render");
        //var tmp = this.model.get('entityView');
		//this.$el.attr('id', this.model.get('cardId'));

		this.$el.html(this.template(this.model.toJSON()));
        this.$el.find('.profileContent').html(this.model.get('entityView').render().el);

        _.each(this.model.get('attributeViews').render(), function(el) {
            this.$el.find('.attrContent').append(el);
        }, this);

		/*
		if (this.model.get('cardType') == "videoCard") {
			this.$el.find('.card-header').hide();
		}
		*/
		return this;
	},
    //Event Handler
    test: function() {
        console.log('hi...');
    }

});

App.CardModel = Backbone.Model.extend({
	defaults: {
		cardTitle: "Enter Title",
		cardContent: "Empty",
		editable: false
	},
	initialize: function(spec) {
		this.on("change:highlight", "toggleHighlight", this);
		this.on("change:content", "updateContent", this);
		this.on("error", function(model, error) {
			console.log(error);
		});
	},
	validate: function(attribs) {
	}
});

App.CardView= Backbone.View.extend({
	template: _.template(Template.cardTemplate),
	events: {
	},
	render: function(event) {
		console.log("App.CardView Render");
		console.log(this.model.get('cardContent'));

		//this.$el.attr('id', this.model.get('cardId'));
		this.$el.html(this.template(this.model.toJSON()));

		/*
		if (this.model.get('cardType') == "videoCard") {
			this.$el.find('.card-header').hide();
		}
		*/
		return this;
	},
	initialize: function(card) {
		console.log("App.CardView initialize");
		this.$el.addClass(card.model.get('cardType'));
		this.model.on('change', this.render, this);
	}
});

//Collections
App.CardCollection = Backbone.Collection.extend({
    model: App.CardModel
});

App.CardCollectionView = Backbone.View.extend({
    events: {
        "click #add": "addCard"
    },
    initialize: function(data) {
        this.data = data;
        this.collection = new App.CardCollection(data);
        this.render();

        this.collection.on("add", this.renderCard, this);
        this.collection.on("remove", this.removeCard, this);
    },
    render: function() {
        var that = this;
        _.each(this.collection.models, function(item) {
            that.renderCard(item);
        }, this);
    },
    renderCard: function(item) {
        var cardView = new App.CardView({
            model: item
        });
        App.NextCol().append(cardView.render().el);
    },
    addCard: function(e) {
        e.preventDefault();
        var newCardModel = new App.CardModel({});
        this.collection.add(newCardModel);
    },
    removeCard: function(removedCard) {
        var removedCardData = removeCard.attributes;
        _.each(removedCardData, function(val, key) {
            if (removedCardData[key] === removedCard.defaults[key]) {
                delete removedCardData;
            }
        });

        //!! Double Chekc !!
        var thatData = this.data;
        _.each(thatData, function(card) {
            if (_.isEqual(card, removedCardData)) {
                thatData.splice(_.indexOf(thatData, card), 1);
            }
        });
    },
});

App.AttributeCollection = Backbone.Collection.extend({
    model: App.AttributeModel
});

App.AttributeCollectionView = Backbone.View.extend({
    initialize: function(data) {
        console.log('Attr Collection View');
        this.collection = new App.AttributeCollection(data);
    },
    render: function() {
        var that = this,
            viewsHTML = '';
            els = [],
        _.each(this.collection.models, function(item) {
            //viewsHTML += that.renderAttribute(item);
            els.push(that.renderAttribute(item));
        }, this);

        return els;
    },
    renderAttribute: function(item) {
        var attrView = new App.AttributeView({
            model: item
        });

        return attrView.render().el;
    }
});

App.SummaryCardCollection = Backbone.Collection.extend({
	url: App.API_VERSION + 'entity/', 
    model: App.SummaryCardModel
});

App.SummaryCardCollectionView = Backbone.View.extend({
    initialize: function(data, query) {
        if (query) {
            //this.url = this.url + "?q=" + query;
            this.collection = new App.SummaryCardCollection();
            this.collection.fetch({data: $.param({q: query})});
        }
        else {
    	    this.collection = new App.SummaryCardCollection();
            this.collection.fetch({data: $.param({q: query})});
        
    //        this.collection = new App.SummaryCardCollection(data);
        }

        this.render();
        this.collection.on("reset", this.render, this);
    },
    render: function() {
        var that = this;
        _.each(this.collection.models, function(item) {
            that.renderSummaryCard(item);
        }, this);
    },
    renderSummaryCard: function(item) {
        var cardView = new App.SummaryCardView({
            model: item
        });
        App.NextCol().append(cardView.render().el);
    }
});

/*
App.Column1 = new cardCollection();
App.Column2 = new cardCollection();
App.Column3 = new cardCollection();
*/

//Utility Functions
App.Cols = [$('#col1'), $('#col2'), $('#col3')];
App.CurrentColIndex = 0; //index to current col
App.NextCol = function() {
	var nextCol = App.Cols[App.CurrentColIndex];
	App.CurrentColIndex = (App.CurrentColIndex+1)%App.Cols.length;
	return nextCol;
}

/*
//The overall container
var BaseColView = Backbone.View.extend({
	el: 'undefined',
	collection: 'undefined',
	events: {
		'change':'render'
	},
	initialize: function() {
		console.log(this.$el);
		console.log(this.collection);
		this.collection.on('add', this.addOne, this);
	},
	render: function() {
		console.log("App.Col render");

		if (collection.length) {
			console.log(collection.length);
		}
		else {
			//this.$el.hide(); //hide the view
		}
	},
	addOne: function(card) {
		var card = new App.CardView({model: card});
		this.$el.append(card.render().el);
	},
	addAll: function() {
		this.$el.html('');
		collection.each(this.addOne, this);
	}
});

App.Col1View = BaseColView.extend({
	el: '#col1',
	collection: App.Column1
});

App.Col2View = BaseColView.extend({
	el: '#col2',
	collection: App.Column2
});

App.Col3View = BaseColView.extend({
	el: '#col3',
	collection: App.Column3
});
*/

